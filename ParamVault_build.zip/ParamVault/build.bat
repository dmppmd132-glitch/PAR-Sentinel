@echo off
chcp 65001 >nul
py -3.12 -m pip install pyinstaller watchdog
py -3.12 -m PyInstaller --noconsole --onefile --clean --name ParamVault --icon "backup-records-icon.ico" --add-data "backup-records-icon.ico;." --add-data "backup-records-icon-48.png;." ParamVault.py
echo.
echo 完成：dist\ParamVault.exe
pause

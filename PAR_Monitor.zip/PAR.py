# -*- coding: utf-8 -*-
"""
PAR 檔案監控器 - Python 3.12
功能：
- 即時監控 .par（watchdog；未安裝時可選輪詢）
- 新增/修改/取代/刪除事件記錄
- 保存變更前版本（以掃描快照快取內容，事件觸發時備份）
- 變更後版本備份
- PAR 文字差異比較（統一 diff）
- GUI 通知與事件清單
- Windows 開機自動啟動捷徑（可選）
介面：左側導覽（監控總覽／事件紀錄／設定）＋右側內容頁
"""
from __future__ import annotations
import difflib
import hashlib
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, date, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_TITLE = "PAR 檔案監控器"
ICON_FILE = "backup-records-icon.ico"
LOGO_FILE = "backup-records-icon-48.png"
DEFAULT_INTERVAL = 5.0        # 網路磁碟機建議 5 秒以上
DELETE_CONFIRM_CYCLES = 2     # 連續幾輪都找不到才算「刪除」（避免網路瞬斷／先刪後寫的取代被誤判）
FULL_VERIFY_EVERY = 60        # 每 N 輪強制完整重讀內容（抓「大小與修改時間都沒變」的取代）
DISK_REFRESH_SEC = 30         # 備份空間更新週期
HOME_EVENT_LIMIT = 30         # 監控總覽只顯示最近 N 筆事件

# ---- 深色主題 ----
BG = "#050d1c"        # 視窗底色
SIDEBAR = "#07142b"   # 左側導覽
PANEL = "#0a1a33"     # 卡片底色
PANEL2 = "#102a4c"    # 輸入框／按鈕／表頭
BORDER = "#17325a"
FG = "#e6f0ff"
MUTED = "#7f93b5"
ACCENT = "#12b3ff"
CYAN = ACCENT
GREEN = "#39e08f"
AMBER = "#ffc83d"
RED = "#ff5d6c"
NAV_ACTIVE = "#0f2a4d"
FONT_UI = ("Microsoft JhengHei UI", 10)
FONT_UI_B = ("Microsoft JhengHei UI", 10, "bold")
FONT_SMALL = ("Microsoft JhengHei UI", 9)
FONT_TITLE = ("Microsoft JhengHei UI", 18, "bold")
FONT_CARD_T = ("Microsoft JhengHei UI", 12, "bold")
FONT_BIG = ("Microsoft JhengHei UI", 18, "bold")
FONT_ICON = ("Segoe UI Symbol", 15)
FONT_MONO = ("Consolas", 10)
ACTION_STYLE = {   # 事件 -> (tag, 圖示)
    "開始": ("start", "●"),
    "新增": ("new", "▲"),
    "修改/取代": ("mod", "◆"),
    "刪除": ("del", "✕"),
}
FILTERS = {"全部事件": None, "新增": "new", "修改/取代": "mod", "刪除": "del"}
PERIODS = ("今日", "近 7 天", "全部")
KIND_BY_LOG = {"新增": "new", "修改/取代": "mod", "刪除": "del", "監控開始": "other"}


def resource_path(name: str) -> str:
    """PyInstaller 打包後從暫存目錄取資源，未打包時從程式所在目錄取。"""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


def apply_icon(root):
    if os.name != "nt":
        return
    try:  # 讓工作列顯示本程式自己的圖示，而不是 python 的
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("PAR.FileMonitor")
    except Exception:
        pass
    try:  # default=True：之後開的子視窗（差異視窗）也會套用
        root.iconbitmap(default=resource_path(ICON_FILE))
    except tk.TclError:
        pass


def is_network_path(path: str) -> bool:
    """UNC 路徑或對應成磁碟機代號的網路磁碟機。"""
    if os.name != "nt":
        return False
    if path.startswith("\\\\"):
        return True
    drive = os.path.splitdrive(path)[0]
    if not drive:
        return False
    try:
        import ctypes
        return ctypes.windll.kernel32.GetDriveTypeW(drive + "\\") == 4  # DRIVE_REMOTE
    except Exception:
        return False


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def scan(folder: str, previous: dict, force_full: bool = False):
    """
    掃描 .par，回傳 {路徑: ((大小, 修改時間ns), 內容bytes)}；資料夾無法存取時回傳 None。
    - 大小與修改時間沒變就沿用快取，不重讀內容（網路磁碟機省流量）。
    - 讀取失敗／檔案還在寫入中／子資料夾暫時讀不到：保留舊版本，絕不因此判成「刪除」。
    """
    if not os.path.isdir(folder):
        return None
    result, failed_dirs = {}, []

    def onerror(err):
        if getattr(err, "filename", None):
            failed_dirs.append(os.path.normcase(str(err.filename)))

    for dirpath, _dirs, files in os.walk(folder, onerror=onerror):
        for name in files:
            if not name.lower().endswith(".par"):
                continue
            path = os.path.join(dirpath, name)
            old = previous.get(path)
            try:
                st = os.stat(path)
                sig = (st.st_size, st.st_mtime_ns)
                if old and old[0] == sig and not force_full:
                    result[path] = old
                    continue
                with open(path, "rb") as f:
                    data = f.read()
                st2 = os.stat(path)
                if (st2.st_size, st2.st_mtime_ns) != sig:   # 讀的當下還在被寫入，下一輪再看
                    if old:
                        result[path] = old
                    continue
                result[path] = (sig, data)
            except OSError:
                if old:
                    result[path] = old
    for path, val in previous.items():
        if path in result:
            continue
        npath = os.path.normcase(path)
        if any(npath.startswith(d.rstrip("\\/") + os.sep) for d in failed_dirs):
            result[path] = val
    return result


def decode_text(data: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp950", "big5", "utf-16"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def parse_par_items(text: str):
    """把 INI 風格的 PAR 文字解析成 [((區段, 參數, 第幾次出現), 值), ...]（保留原順序）。"""
    items, section, seen = [], "", {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith((";", "#")):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if "=" not in line:
            continue
        key, value = (x.strip() for x in line.split("=", 1))
        n = seen[(section, key)] = seen.get((section, key), 0) + 1
        items.append(((section, key, n), value))
    return items


def summarize_changes(old: bytes, new: bytes, limit: int = 12):
    """回傳參數層級的變更摘要，例如 'bEnableGoldenDiff = 1 > 0'；無法解析時回傳 None。"""
    try:
        a, b = parse_par_items(decode_text(old)), parse_par_items(decode_text(new))
    except Exception:
        return None
    da, db = dict(a), dict(b)
    parts = []
    for k, v in a:
        if k not in db:
            parts.append((k, f"{k[1]} 刪除（原值 {v}）"))
        elif db[k] != v:
            parts.append((k, f"{k[1]} = {v} > {db[k]}"))
    for k, v in b:
        if k not in da:
            parts.append((k, f"{k[1]} 新增 = {v}"))
    if not parts:
        return None
    order = {k: i for i, (k, _) in enumerate(b)}
    parts.sort(key=lambda p: order.get(p[0], 10 ** 6))
    out = [txt for _, txt in parts[:limit]]
    text = "; ".join(out)
    if len(parts) > limit:
        text += f"; …共 {len(parts)} 項"
    return text


class Toggle(tk.Canvas):
    """設定頁用的開關（綁定 BooleanVar）。"""
    def __init__(self, parent, variable, bg=PANEL):
        super().__init__(parent, width=46, height=24, bg=bg, highlightthickness=0, cursor="hand2")
        self.var = variable
        self.bind("<Button-1>", lambda e: self.var.set(not self.var.get()))
        self.var.trace_add("write", lambda *a: self._draw())
        self._draw()

    def _draw(self):
        self.delete("all")
        on = bool(self.var.get())
        col = ACCENT if on else "#27406b"
        self.create_oval(1, 1, 23, 23, fill=col, outline=col)
        self.create_oval(23, 1, 45, 23, fill=col, outline=col)
        self.create_rectangle(12, 1, 34, 23, fill=col, outline=col)
        cx = 34 if on else 12
        self.create_oval(cx - 9, 3, cx + 9, 21, fill="#ffffff", outline="#ffffff")


class ParMonitor:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1200x780")
        self.root.minsize(1100, 700)
        apply_icon(self.root)
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.wake_event = threading.Event()
        self.offline = False
        self.worker = None
        self.observer = None
        self.previous = {}
        self.folder = None
        self.backup = None
        self.log_path = None
        self.last_sync = None      # 最後一次成功掃描的時間（worker 寫、UI 讀）
        self.disk = None           # (total, used, free) bytes（worker 寫、UI 讀）
        self._disk_shown = None
        self.ever_started = False
        self.folder_var = tk.StringVar()
        self.backup_var = tk.StringVar()
        self.interval_var = tk.StringVar(value=str(DEFAULT_INTERVAL))
        self.autostart_var = tk.BooleanVar(value=False)
        self.notify_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="待機中")
        self.sub_var = tk.StringVar(value="尚未開始")
        self.mode_var = tk.StringVar(value="模式：--")
        self.clock_var = tk.StringVar(value="")
        self.today_var = tk.StringVar(value="0")
        self.delta_var = tk.StringVar(value="— 較昨日")
        self.disk_var = tk.StringVar(value="-- GB")
        self.disk_sub_var = tk.StringVar(value="尚未取得")
        self.sync_var = tk.StringVar(value="--")
        self.sync_sub_var = tk.StringVar(value="尚未同步")
        self.home_count_var = tk.StringVar(value="共 0 筆事件")
        self.ev_count_var = tk.StringVar(value="共 0 筆事件")
        self.folder_show_var = tk.StringVar(value="監控資料夾：尚未設定")
        self.backup_show_var = tk.StringVar(value="備份資料夾：尚未設定")
        self.cfg_note_var = tk.StringVar(value="資料夾與輪詢間隔會在按下「開始監控」時套用。")
        self.filter_var = tk.StringVar(value="全部事件")
        self.period_var = tk.StringVar(value=PERIODS[0])
        self.activity_vars = {k: tk.StringVar(value="0") for k in ("new", "mod", "del", "other")}
        self.rows = []             # 全部事件（iid, 時間, 事件, 檔名, 備註, tag）
        self.day_counts = {}       # {"YYYY-MM-DD": {new, mod, del, other}}
        self._eid = 0
        self._diff_cache = {}
        self._cfg_widgets = []
        self.nav = {}
        self.t0 = None
        self.phase = 0
        self._style()
        self._ui()
        self.folder_var.trace_add("write", lambda *a: self._refresh_paths())
        self.backup_var.trace_add("write", lambda *a: self._refresh_paths())
        self.root.after(100, self._dark_titlebar)
        self.root.after(300, self._tick)
        self.root.after(100, self._poll_ui)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    # ------------------------------------------------------------------ 外觀
    def _style(self):
        st = ttk.Style()
        try: st.theme_use("clam")
        except tk.TclError: pass
        self.root.configure(bg=BG)
        self.root.option_add("*TCombobox*Listbox.background", PANEL2)
        self.root.option_add("*TCombobox*Listbox.foreground", FG)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", "#001820")
        self.root.option_add("*TCombobox*Listbox.font", FONT_UI)
        st.configure(".", background=BG, foreground=FG, fieldbackground=PANEL, bordercolor=BORDER,
                     lightcolor=BORDER, darkcolor=BORDER, troughcolor=PANEL, font=FONT_UI,
                     focuscolor=BG, selectbackground="#17406b", selectforeground="#ffffff")
        st.configure("TFrame", background=BG)
        st.configure("TEntry", fieldbackground=PANEL2, foreground=FG, insertcolor=ACCENT,
                     bordercolor=BORDER, padding=7, font=FONT_UI)
        st.map("TEntry", bordercolor=[("focus", ACCENT)], lightcolor=[("focus", ACCENT)],
               darkcolor=[("focus", ACCENT)], fieldbackground=[("disabled", PANEL)],
               foreground=[("disabled", MUTED)])
        st.configure("TSpinbox", fieldbackground=PANEL2, foreground=FG, insertcolor=ACCENT,
                     bordercolor=BORDER, arrowcolor=ACCENT, background=PANEL2, padding=6, font=FONT_UI)
        st.map("TSpinbox", bordercolor=[("focus", ACCENT)], fieldbackground=[("disabled", PANEL)],
               foreground=[("disabled", MUTED)])
        st.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=FG,
                     arrowcolor=ACCENT, bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER, padding=5)
        st.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", FG)],
               selectbackground=[("readonly", PANEL2)], selectforeground=[("readonly", FG)],
               bordercolor=[("focus", ACCENT)])
        st.configure("TButton", background=PANEL2, foreground=FG, bordercolor=BORDER, padding=(16, 8),
                     focusthickness=0, font=FONT_UI)
        st.map("TButton", background=[("active", "#17406b"), ("disabled", PANEL)],
               foreground=[("disabled", "#44587c")], bordercolor=[("active", ACCENT), ("disabled", BORDER)])
        st.configure("Accent.TButton", background=ACCENT, foreground="#00131c", bordercolor=ACCENT,
                     font=FONT_UI_B, padding=(18, 9))
        st.map("Accent.TButton", background=[("active", "#5cd0ff"), ("disabled", "#0f3a52")],
               foreground=[("disabled", "#3c6a85")], bordercolor=[("disabled", "#0f3a52")])
        st.configure("Danger.TButton", background="#2a1220", foreground=RED, bordercolor=RED,
                     font=FONT_UI_B, padding=(18, 9))
        st.map("Danger.TButton", background=[("active", "#3d1a2d"), ("disabled", PANEL)],
               foreground=[("disabled", "#5a3a48")], bordercolor=[("disabled", BORDER)])
        st.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG, rowheight=30,
                     borderwidth=0, font=FONT_UI)
        st.map("Treeview", background=[("selected", "#17406b")], foreground=[("selected", "#ffffff")])
        st.configure("Treeview.Heading", background=PANEL2, foreground=FG, relief="flat",
                     font=FONT_UI_B, padding=(8, 7))
        st.map("Treeview.Heading", background=[("active", "#17406b")])
        st.configure("Vertical.TScrollbar", background=PANEL2, troughcolor=PANEL, bordercolor=PANEL,
                     arrowcolor=ACCENT, lightcolor=PANEL2, darkcolor=PANEL2, arrowsize=14)
        st.map("Vertical.TScrollbar", background=[("active", "#17406b")])

    def _dark_titlebar(self):
        # Windows 10/11：標題列改深色
        if os.name != "nt": return
        try:
            import ctypes
            self.root.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            val = ctypes.c_int(1)
            for attr in (20, 19):
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)) == 0:
                    break
        except Exception:
            pass

    def _card(self, parent):
        return tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1, bd=0)

    @staticmethod
    def _short(text, n=64):
        return text if len(text) <= n else "…" + text[-(n - 1):]

    # ------------------------------------------------------------------ 版面骨架
    def _ui(self):
        self.root.columnconfigure(1, weight=1)
        self.root.rowconfigure(0, weight=1)
        self._build_sidebar()

        main = tk.Frame(self.root, bg=BG)
        main.grid(row=0, column=1, sticky="nsew", padx=22, pady=(14, 18))
        main.columnconfigure(0, weight=1)
        main.rowconfigure(2, weight=1)

        # --- 頂部標題列 ---
        head = tk.Frame(main, bg=BG)
        head.grid(row=0, column=0, sticky="ew")
        pill = tk.Frame(head, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        pill.pack(side="right")
        self.led = tk.Canvas(pill, width=14, height=14, bg=PANEL, highlightthickness=0)
        self.led.pack(side="left", padx=(14, 6), pady=10)
        self.led_dot = self.led.create_oval(2, 2, 12, 12, fill=MUTED, outline=MUTED)
        tk.Label(pill, textvariable=self.status_var, bg=PANEL, fg=FG, font=FONT_UI_B, width=12,
                 anchor="w").pack(side="left", padx=(0, 14))
        tk.Label(head, text=APP_TITLE, bg=BG, fg=FG, font=FONT_TITLE).pack(side="left")
        tk.Frame(head, bg=BORDER, width=1, height=22).pack(side="left", padx=14)
        tk.Label(head, text="監控資料夾中的變更，自動備份 .par 檔案", bg=BG, fg=MUTED,
                 font=FONT_SMALL).pack(side="left")
        tk.Frame(main, bg=BORDER, height=1).grid(row=1, column=0, sticky="ew", pady=(12, 14))

        # --- 頁面容器 ---
        host = tk.Frame(main, bg=BG)
        host.grid(row=2, column=0, sticky="nsew")
        host.columnconfigure(0, weight=1)
        host.rowconfigure(0, weight=1)
        self.pages = {
            "home": self._build_home(host),
            "events": self._build_events(host),
            "settings": self._build_settings(host),
        }
        for page in self.pages.values():
            page.grid(row=0, column=0, sticky="nsew")
        self.show_page("home")
        self._refresh_paths()
        self._refresh_counts()

    def _build_sidebar(self):
        side = tk.Frame(self.root, bg=SIDEBAR, width=220)
        side.grid(row=0, column=0, sticky="ns")
        side.pack_propagate(False)
        tk.Frame(self.root, bg=BORDER, width=1).grid(row=0, column=0, sticky="nse")
        try:
            self._logo = tk.PhotoImage(file=resource_path(LOGO_FILE))
            tk.Label(side, image=self._logo, bg=SIDEBAR).pack(pady=(26, 8))
        except Exception:
            c = tk.Canvas(side, width=56, height=56, bg=SIDEBAR, highlightthickness=0)
            c.create_oval(3, 3, 53, 53, outline=ACCENT, width=3)
            c.create_text(28, 28, text="P", fill=ACCENT, font=("Consolas", 22, "bold"))
            c.pack(pady=(26, 8))
        tk.Label(side, text=APP_TITLE, bg=SIDEBAR, fg=FG, font=("Microsoft JhengHei UI", 13, "bold")).pack()
        tk.Label(side, text="即時監控 · 自動備份 · 守護資料", bg=SIDEBAR, fg=MUTED,
                 font=("Microsoft JhengHei UI", 8)).pack(pady=(4, 26))
        self._nav_item(side, "home", "⌂", "監控總覽")
        self._nav_item(side, "events", "☰", "事件紀錄")
        self._nav_item(side, "settings", "⚙", "設定")
        tk.Label(side, textvariable=self.clock_var, bg=SIDEBAR, fg=MUTED, font=FONT_MONO).pack(side="bottom", pady=16)

    def _nav_item(self, parent, key, icon, text):
        f = tk.Frame(parent, bg=SIDEBAR, cursor="hand2", highlightthickness=1, highlightbackground=SIDEBAR)
        f.pack(fill="x", padx=12, pady=3)
        i = tk.Label(f, text=icon, bg=SIDEBAR, fg=ACCENT, font=FONT_ICON, width=2)
        i.pack(side="left", padx=(12, 4), pady=9)
        t = tk.Label(f, text=text, bg=SIDEBAR, fg=FG, font=FONT_UI)
        t.pack(side="left")
        for w in (f, i, t):
            w.bind("<Button-1>", lambda e, k=key: self.show_page(k))
        self.nav[key] = (f, i, t)

    def show_page(self, key):
        self.pages[key].tkraise()
        for k, (f, i, t) in self.nav.items():
            on = (k == key)
            bg = NAV_ACTIVE if on else SIDEBAR
            f.configure(bg=bg, highlightbackground=ACCENT if on else SIDEBAR)
            i.configure(bg=bg)
            t.configure(bg=bg)

    # ------------------------------------------------------------------ 頁面：監控總覽
    def _build_home(self, host):
        page = tk.Frame(host, bg=BG)
        page.columnconfigure(0, weight=1)
        page.rowconfigure(2, weight=1)

        # 控制列：按鈕先 pack 到右側，保證「停止監控」一定完整顯示，路徑文字被擠時才縮短
        bar = self._card(page)
        bar.grid(row=0, column=0, sticky="ew")
        inner = tk.Frame(bar, bg=PANEL)
        inner.pack(fill="x", padx=18, pady=14)
        self.stop_btn = ttk.Button(inner, text="■  停止監控", style="Danger.TButton", width=13,
                                   command=self.stop, state="disabled")
        self.stop_btn.pack(side="right")
        self.start_btn = ttk.Button(inner, text="▶  開始監控", style="Accent.TButton", width=13,
                                    command=self.start)
        self.start_btn.pack(side="right", padx=(0, 10))
        info = tk.Frame(inner, bg=PANEL)
        info.pack(side="left", fill="x", expand=True)
        for var, fg in ((self.folder_show_var, FG), (self.backup_show_var, FG), (self.mode_var, MUTED)):
            tk.Label(info, textvariable=var, bg=PANEL, fg=fg, font=FONT_SMALL, anchor="w").pack(fill="x")
        link = tk.Label(info, text="⚙ 前往設定變更路徑與間隔", bg=PANEL, fg=ACCENT, font=FONT_SMALL,
                        cursor="hand2", anchor="w")
        link.pack(fill="x", pady=(2, 0))
        link.bind("<Button-1>", lambda e: self.show_page("settings"))

        # 統計卡片
        stats = tk.Frame(page, bg=BG)
        stats.grid(row=1, column=0, sticky="ew", pady=(14, 0))
        for i in range(4):
            stats.columnconfigure(i, weight=1)
        self._stat_card(stats, 0, "◉", "監控狀態", self.status_var, self.sub_var)
        self._stat_card(stats, 1, "▤", "今日事件", self.today_var, self.delta_var)
        disk = self._stat_card(stats, 2, "▣", "備份空間（可用）", self.disk_var, self.disk_sub_var, ring=True)
        self._stat_card(stats, 3, "◷", "最後同步", self.sync_var, self.sync_sub_var)

        # 下半：最近事件 + 活動摘要
        low = tk.Frame(page, bg=BG)
        low.grid(row=2, column=0, sticky="nsew", pady=(14, 0))
        low.columnconfigure(0, weight=1)
        low.columnconfigure(1, weight=0, minsize=250)
        low.rowconfigure(0, weight=1)

        log = self._card(low)
        log.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        log.columnconfigure(0, weight=1)
        log.rowconfigure(1, weight=1)
        top = tk.Frame(log, bg=PANEL)
        top.grid(row=0, column=0, sticky="ew", padx=16, pady=(14, 8))
        tk.Label(top, text="☰", bg=PANEL, fg=ACCENT, font=FONT_ICON).pack(side="left")
        tk.Label(top, text="最近事件", bg=PANEL, fg=FG, font=FONT_CARD_T).pack(side="left", padx=(8, 6))
        tk.Label(top, text="（雙擊事件可查看差異）", bg=PANEL, fg=MUTED, font=FONT_SMALL).pack(side="left")
        more = tk.Label(top, text="查看全部 ›", bg=PANEL, fg=ACCENT, font=FONT_SMALL, cursor="hand2")
        more.pack(side="right")
        more.bind("<Button-1>", lambda e: self.show_page("events"))
        tk.Label(top, textvariable=self.home_count_var, bg=PANEL, fg=MUTED, font=FONT_SMALL).pack(side="right", padx=14)
        wrap, self.home_tree = self._make_tree(log, 8)
        wrap.grid(row=1, column=0, sticky="nsew", padx=16, pady=(0, 14))

        act = self._card(low)
        act.grid(row=0, column=1, sticky="nsew")
        top = tk.Frame(act, bg=PANEL)
        top.pack(fill="x", padx=16, pady=(14, 8))
        tk.Label(top, text="▮▮", bg=PANEL, fg=ACCENT, font=("Segoe UI Symbol", 11)).pack(side="left")
        tk.Label(top, text="活動摘要", bg=PANEL, fg=FG, font=FONT_CARD_T).pack(side="left", padx=(8, 0))
        cb = ttk.Combobox(top, textvariable=self.period_var, values=PERIODS, state="readonly", width=7)
        cb.pack(side="right")
        cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_counts())
        for key, icon, label, color in (("new", "▲", "新增", GREEN), ("mod", "◆", "修改/取代", AMBER),
                                        ("del", "✕", "刪除", RED), ("other", "●", "其他", MUTED)):
            row = tk.Frame(act, bg=PANEL)
            row.pack(fill="x", padx=16, pady=9)
            tk.Label(row, text=icon, bg=PANEL, fg=color, font=FONT_UI_B, width=2).pack(side="left")
            tk.Label(row, text=label, bg=PANEL, fg=FG, font=FONT_UI).pack(side="left", padx=(4, 0))
            tk.Label(row, textvariable=self.activity_vars[key], bg=PANEL, fg=FG,
                     font=("Microsoft JhengHei UI", 12, "bold")).pack(side="right")
        return page

    def _stat_card(self, parent, col, icon, caption, var, subvar, ring=False):
        card = self._card(parent)
        card.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 12, 0))
        inner = tk.Frame(card, bg=PANEL)
        inner.pack(fill="both", expand=True, padx=14, pady=14)
        tk.Label(inner, text=icon, bg=PANEL, fg=ACCENT, font=("Segoe UI Symbol", 20)).pack(side="left", padx=(0, 10))
        if ring:
            self.ring = tk.Canvas(inner, width=54, height=54, bg=PANEL, highlightthickness=0)
            self.ring.pack(side="right", padx=(6, 0))
            self._draw_ring(None)
        box = tk.Frame(inner, bg=PANEL)
        box.pack(side="left", fill="x", expand=True)
        tk.Label(box, text=caption, bg=PANEL, fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x")
        tk.Label(box, textvariable=var, bg=PANEL, fg=FG, font=FONT_BIG, anchor="w").pack(fill="x")
        tk.Label(box, textvariable=subvar, bg=PANEL, fg=MUTED, font=FONT_SMALL, anchor="w").pack(fill="x")
        return card

    def _draw_ring(self, pct):
        c = self.ring
        c.delete("all")
        c.create_oval(6, 6, 48, 48, outline="#16325c", width=6)
        if pct is not None:
            color = RED if pct >= 90 else AMBER if pct >= 75 else ACCENT
            c.create_arc(6, 6, 48, 48, start=90, extent=-min(359.9, max(1.0, pct * 3.6)),
                         style="arc", outline=color, width=6)
        c.create_text(27, 27, text="--" if pct is None else f"{pct:.0f}%", fill=MUTED, font=("Consolas", 9))

    def _make_tree(self, parent, height):
        wrap = tk.Frame(parent, bg=PANEL)
        wrap.columnconfigure(0, weight=1)
        wrap.rowconfigure(0, weight=1)
        tree = ttk.Treeview(wrap, columns=("time", "action", "file", "details"), show="headings",
                            height=height, selectmode="browse")
        for col, title, width, stretch in (("time", "時間", 150, False), ("action", "事件", 105, False),
                                           ("file", "PAR 檔案", 150, False), ("details", "備註", 200, True)):
            tree.heading(col, text=title, anchor="w")
            tree.column(col, width=width, minwidth=70, anchor="w", stretch=stretch)
        tree.grid(row=0, column=0, sticky="nsew")
        ys = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        ys.grid(row=0, column=1, sticky="ns")
        tree.configure(yscrollcommand=ys.set)
        for tag, color in (("start", ACCENT), ("new", GREEN), ("mod", AMBER), ("del", RED)):
            tree.tag_configure(tag, foreground=color)
        tree.bind("<Double-1>", self.show_diff)
        return wrap, tree

    # ------------------------------------------------------------------ 頁面：事件紀錄
    def _build_events(self, host):
        page = tk.Frame(host, bg=BG)
        page.columnconfigure(0, weight=1)
        page.rowconfigure(0, weight=1)
        card = self._card(page)
        card.grid(row=0, column=0, sticky="nsew")
        card.columnconfigure(0, weight=1)
        card.rowconfigure(1, weight=1)
        top = tk.Frame(card, bg=PANEL)
        top.grid(row=0, column=0, sticky="ew", padx=18, pady=(16, 10))
        tk.Label(top, text="☰", bg=PANEL, fg=ACCENT, font=FONT_ICON).pack(side="left")
        tk.Label(top, text="事件紀錄", bg=PANEL, fg=FG, font=FONT_CARD_T).pack(side="left", padx=(8, 6))
        tk.Label(top, text="（雙擊事件可查看差異）", bg=PANEL, fg=MUTED, font=FONT_SMALL).pack(side="left")
        cb = ttk.Combobox(top, textvariable=self.filter_var, values=list(FILTERS), state="readonly", width=10)
        cb.pack(side="right")
        cb.bind("<<ComboboxSelected>>", lambda e: self._refill_events())
        tk.Label(top, textvariable=self.ev_count_var, bg=PANEL, fg=MUTED, font=FONT_SMALL).pack(side="right", padx=14)
        wrap, self.ev_tree = self._make_tree(card, 18)
        wrap.grid(row=1, column=0, sticky="nsew", padx=18, pady=(0, 16))
        return page

    # ------------------------------------------------------------------ 頁面：設定
    def _build_settings(self, host):
        page = tk.Frame(host, bg=BG)
        page.columnconfigure(0, weight=1)

        # --- 區塊 1：資料夾 ---
        body = self._section(page, 0, "▤", "資料夾", "指定要監控的來源，以及存放備份的位置")
        self._path_row(body, 0, "監控資料夾",
                       "可選擇網路磁碟機或輸入 \\\\主機\\分享；含子資料夾；只監控 .par",
                       self.folder_var, self.pick_folder)
        self._path_row(body, 1, "備份資料夾",
                       "存放變更前後版本、差異檔與 Log（不可位於監控資料夾內）",
                       self.backup_var, self.pick_backup)
        btns = tk.Frame(body, bg=PANEL)
        btns.grid(row=2, column=0, sticky="w", pady=(4, 0))
        ttk.Button(btns, text="開啟備份資料夾", command=self.open_backup).pack(side="left")
        ttk.Button(btns, text="開啟 Log", command=self.open_log).pack(side="left", padx=10)

        # --- 區塊 2：監控選項（開關式列表） ---
        body = self._section(page, 1, "⚙", "監控選項", "調整偵測頻率與提醒方式")
        body.columnconfigure(0, weight=1)
        def make_spin(parent):
            sp = ttk.Spinbox(parent, from_=0.5, to=3600, increment=0.5, textvariable=self.interval_var,
                             width=7, justify="center")
            self._cfg_widgets.append(sp)
            return sp
        self._option_row(body, 0, "輪詢間隔（秒）", "網路磁碟機建議 5 秒以上；最小 0.5 秒", make_spin)
        self._option_row(body, 2, "變更時跳通知", "偵測到新增／修改／刪除時，在狀態列提示",
                         lambda p: Toggle(p, self.notify_var))
        self._option_row(body, 4, "加入 Windows 開機啟動", "於「開始監控」時建立啟動資料夾捷徑",
                         lambda p: Toggle(p, self.autostart_var))

        tk.Label(page, textvariable=self.cfg_note_var, bg=BG, fg=MUTED, font=FONT_SMALL,
                 anchor="w").grid(row=2, column=0, sticky="w", pady=(2, 0))
        return page

    def _section(self, page, row, icon, title, desc):
        card = self._card(page)
        card.grid(row=row, column=0, sticky="ew", pady=(0, 14))
        card.columnconfigure(0, weight=1)
        top = tk.Frame(card, bg=PANEL)
        top.grid(row=0, column=0, sticky="ew", padx=20, pady=(16, 0))
        tk.Label(top, text=icon, bg=PANEL, fg=ACCENT, font=FONT_ICON).pack(side="left")
        tk.Label(top, text=title, bg=PANEL, fg=FG, font=FONT_CARD_T).pack(side="left", padx=(8, 10))
        tk.Label(top, text=desc, bg=PANEL, fg=MUTED, font=FONT_SMALL).pack(side="left")
        tk.Frame(card, bg=BORDER, height=1).grid(row=1, column=0, sticky="ew", padx=20, pady=(12, 12))
        body = tk.Frame(card, bg=PANEL)
        body.grid(row=2, column=0, sticky="ew", padx=20, pady=(0, 16))
        body.columnconfigure(0, weight=1)
        return body

    def _path_row(self, body, row, title, hint, var, cmd):
        f = tk.Frame(body, bg=PANEL)
        f.grid(row=row, column=0, sticky="ew", pady=(0, 12))
        f.columnconfigure(0, weight=1)
        tk.Label(f, text=title, bg=PANEL, fg=FG, font=FONT_UI_B, anchor="w").grid(row=0, column=0, columnspan=2, sticky="w")
        tk.Label(f, text=hint, bg=PANEL, fg=MUTED, font=FONT_SMALL, anchor="w").grid(row=1, column=0, columnspan=2, sticky="w", pady=(2, 6))
        ent = ttk.Entry(f, textvariable=var)
        ent.grid(row=2, column=0, sticky="ew", padx=(0, 10))
        btn = ttk.Button(f, text="選擇…", command=cmd)
        btn.grid(row=2, column=1)
        self._cfg_widgets += [ent, btn]

    def _option_row(self, body, row, title, desc, make):
        f = tk.Frame(body, bg=PANEL)
        f.grid(row=row, column=0, sticky="ew", pady=8)
        f.columnconfigure(0, weight=1)
        tk.Label(f, text=title, bg=PANEL, fg=FG, font=FONT_UI_B, anchor="w").grid(row=0, column=0, sticky="w")
        tk.Label(f, text=desc, bg=PANEL, fg=MUTED, font=FONT_SMALL, anchor="w").grid(row=1, column=0, sticky="w")
        make(f).grid(row=0, column=1, rowspan=2, sticky="e", padx=(12, 0))
        if row < 4:
            tk.Frame(body, bg=BORDER, height=1).grid(row=row + 1, column=0, sticky="ew")

    # ------------------------------------------------------------------ 狀態與統計
    def _refresh_paths(self):
        f, b = self.folder_var.get().strip(), self.backup_var.get().strip()
        self.folder_show_var.set("監控資料夾：" + (self._short(f) if f else "尚未設定"))
        self.backup_show_var.set("備份資料夾：" + (self._short(b) if b else "尚未設定"))

    def _idle_status(self):
        if self.worker and self.worker.is_alive() and not self.stop_event.is_set():
            return "離線" if self.offline else "監控中"
        return "待機中"

    def _bump(self, day, kind):
        d = self.day_counts.setdefault(day, {"new": 0, "mod": 0, "del": 0, "other": 0})
        d[kind] += 1

    def _day_total(self, day):
        d = self.day_counts.get(day)
        return (d["new"] + d["mod"] + d["del"]) if d else 0

    def _refresh_counts(self):
        today = date.today()
        t, y = self._day_total(today.isoformat()), self._day_total((today - timedelta(days=1)).isoformat())
        self.today_var.set(str(t))
        diff = t - y
        self.delta_var.set("— 較昨日" if diff == 0 else f"{'▲ +' if diff > 0 else '▼ −'}{abs(diff)} 較昨日")
        period = self.period_var.get()
        if period == "今日":
            days = {today.isoformat()}
        elif period == "近 7 天":
            days = {(today - timedelta(days=i)).isoformat() for i in range(7)}
        else:
            days = set(self.day_counts)
        for key, var in self.activity_vars.items():
            var.set(str(sum(self.day_counts[d][key] for d in days if d in self.day_counts)))

    def _tick(self):
        # 每 0.5 秒：時鐘、運行時間、狀態燈呼吸、最後同步、備份空間
        self.phase = (self.phase + 1) % 2
        self.clock_var.set(datetime.now().strftime("%Y-%m-%d  %H:%M:%S"))
        running = bool(self.worker and self.worker.is_alive() and not self.stop_event.is_set())
        if running and self.t0:
            sec = int(time.time() - self.t0)
            self.sub_var.set(f"已運行 {sec // 3600:02d}:{sec % 3600 // 60:02d}:{sec % 60:02d} · {len(self.previous)} 個檔案")
            if self.offline:
                color = AMBER if self.phase else "#6b4a1c"
            else:
                color = GREEN if self.phase else "#12894f"
        else:
            self.sub_var.set("已停止" if self.ever_started else "尚未開始")
            color = MUTED
        self.led.itemconfigure(self.led_dot, fill=color, outline=color)
        ls = self.last_sync
        if ls:
            ago = int(time.time() - ls)
            self.sync_var.set(datetime.fromtimestamp(ls).strftime("%H:%M:%S"))
            self.sync_sub_var.set("剛剛" if ago < 2 else f"{ago} 秒前" if ago < 120 else f"{ago // 60} 分鐘前")
        disk = self.disk
        if disk and disk != self._disk_shown:
            self._disk_shown = disk
            total, used, free = disk
            pct = used * 100 / total if total else 0
            self.disk_var.set(f"{free / 1024 ** 3:,.1f} GB")
            self.disk_sub_var.set(f"共 {total / 1024 ** 3:,.0f} GB · 已用 {pct:.0f}%")
            self._draw_ring(pct)
        self.root.after(500, self._tick)

    # ------------------------------------------------------------------ 事件列表
    def _record_event(self, action, name, detail, path=None, old=None, new=None, t=None):
        tag, icon = ACTION_STYLE.get(action, ("start", "●"))
        self._eid += 1
        iid = str(self._eid)
        row = (iid, t or datetime.now().strftime("%Y-%m-%d %H:%M:%S"), f"{icon} {action}", name, detail, tag)
        self.rows.append(row)
        self._diff_cache[iid] = (path, old, new)
        self._bump(date.today().isoformat(), tag if tag in ("new", "mod", "del") else "other")
        self._insert_row(self.home_tree, row, limit=HOME_EVENT_LIMIT)
        if self._filter_match(row):
            self._insert_row(self.ev_tree, row)
        self.home_count_var.set(f"共 {len(self.rows)} 筆事件")
        self.ev_count_var.set(f"共 {len(self.ev_tree.get_children())} 筆事件")
        self._refresh_counts()

    def _insert_row(self, tree, row, limit=None):
        iid, t, action, name, detail, tag = row
        tree.insert("", "end", iid=iid, values=(t, action, name, detail), tags=(tag,))
        tree.see(iid)
        if limit:
            kids = tree.get_children()
            if len(kids) > limit:
                tree.delete(kids[0])

    def _filter_match(self, row):
        want = FILTERS.get(self.filter_var.get())
        return want is None or row[5] == want

    def _refill_events(self):
        self.ev_tree.delete(*self.ev_tree.get_children())
        for row in self.rows:
            if self._filter_match(row):
                self.ev_tree.insert("", "end", iid=row[0], values=row[1:5], tags=(row[5],))
        kids = self.ev_tree.get_children()
        self.ev_count_var.set(f"共 {len(kids)} 筆事件")
        if kids:
            self.ev_tree.see(kids[-1])

    def _load_history(self):
        """從既有 Log 還原每日事件數（供「較昨日」與活動摘要使用）。"""
        self.day_counts = {}
        try:
            with self.log_path.open(encoding="utf-8") as f:
                for line in f:
                    if len(line) < 30 or not line.startswith("["):
                        continue
                    kind = KIND_BY_LOG.get(line[line.find("] ") + 2:].split(" | ", 1)[0])
                    if kind:
                        self._bump(line[1:11], kind)
        except OSError:
            pass

    def pick_folder(self):
        p = filedialog.askdirectory(title="選擇監控資料夾")
        if p: self.folder_var.set(p)

    def pick_backup(self):
        p = filedialog.askdirectory(title="選擇備份資料夾")
        if p: self.backup_var.set(p)

    def start(self):
        folder_text = self.folder_var.get().strip()
        backup_text = self.backup_var.get().strip()
        folder = os.path.normpath(os.path.abspath(folder_text)) if folder_text else ""
        if not folder or not os.path.isdir(folder):
            self.show_page("settings"); messagebox.showerror("設定錯誤", "請選擇有效的監控資料夾。"); return
        if not backup_text:
            self.show_page("settings"); messagebox.showerror("設定錯誤", "請選擇備份資料夾。"); return
        try:
            interval = float(self.interval_var.get())
            if interval < 0.5: raise ValueError
        except ValueError:
            self.show_page("settings"); messagebox.showerror("設定錯誤", "輪詢間隔需為 0.5 秒以上。"); return
        backup = Path(os.path.normpath(os.path.abspath(backup_text)))
        if self._inside(str(backup), folder):
            self.show_page("settings"); messagebox.showerror("設定錯誤", "備份資料夾不可位於監控資料夾內。"); return
        try: backup.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            self.show_page("settings"); messagebox.showerror("設定錯誤", f"無法建立備份資料夾：{e}"); return

        self.folder, self.backup = folder, backup
        self.log_path = backup / "PAR_monitor.log"
        self.previous = scan(folder, {}) or {}
        self._load_history()
        self.last_sync, self.disk, self._disk_shown = time.time(), None, None
        self.ever_started = True
        self.offline = False
        self.stop_event.clear()
        self.wake_event.clear()
        self._log(f"監控開始 | folder={folder} | backup={backup} | 網路路徑={is_network_path(folder)} | 初始檔案數={len(self.previous)}")
        self._record_event("開始", "-", f"初始掃描 {len(self.previous)} 個 PAR")
        self._start_watchdog()
        net = is_network_path(folder)
        self.mode_var.set(f"模式：{'網路磁碟機 · 輪詢' if net else '本機 · 即時事件 + 輪詢'} · 每 {interval:g} 秒")
        self.t0 = time.time()
        self.worker = threading.Thread(target=self._poll_loop, args=(interval,), daemon=True)
        self.worker.start()
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_var.set("監控中")
        self._set_cfg_enabled(False)
        if self.autostart_var.get():
            try:
                self.install_autostart()
                self._log("已設定 Windows 開機啟動捷徑")
            except Exception as e:
                self._log(f"開機啟動設定失敗 | {e}")

    @staticmethod
    def _inside(child: str, parent: str) -> bool:
        """child 是否等於或位於 parent 內（同時比對原路徑與解析後路徑，涵蓋磁碟機代號 vs UNC）。"""
        def norm(x): return os.path.normcase(os.path.normpath(x)).rstrip("\\/")
        pairs = [(child, parent)]
        try: pairs.append((str(Path(child).resolve()), str(Path(parent).resolve())))
        except OSError: pass
        return any(norm(c) == norm(p) or norm(c).startswith(norm(p) + os.sep) for c, p in pairs)

    def _start_watchdog(self):
        if is_network_path(self.folder):
            # SMB 網路磁碟機不保證送出檔案變更通知，直接以輪詢為準
            self.observer = None
            self._log("監控目標為網路磁碟機：不使用 watchdog，改用輪詢")
            return
        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
            app = self
            class Handler(FileSystemEventHandler):
                def on_any_event(self, event):
                    if event.is_directory: return
                    src = getattr(event, "src_path", "")
                    dest = getattr(event, "dest_path", "")
                    if src.lower().endswith(".par") or dest.lower().endswith(".par"):
                        app.wake_event.set()
            self.observer = Observer()
            self.observer.schedule(Handler(), str(self.folder), recursive=True)
            self.observer.start()
            self._log("即時事件監控已啟動（watchdog）")
        except ImportError:
            self.observer = None
            self._log("未安裝 watchdog，使用輪詢監控；可執行 pip install watchdog")
        except Exception as e:
            self.observer = None
            self._log(f"即時監控啟動失敗，改用輪詢 | {e}")

    def _poll_loop(self, interval):
        cycle, missing, last_disk = 0, {}, 0.0
        while not self.stop_event.is_set():
            cycle += 1
            current = scan(self.folder, self.previous, force_full=(cycle % FULL_VERIFY_EVERY == 0))
            if current is None:
                if not self.offline:
                    self.offline = True
                    self._log("監控資料夾無法存取（網路磁碟機可能中斷），暫停比對，等待恢復")
                    self.events.put(("state", "offline"))
            else:
                if self.offline:
                    self.offline = False
                    self._log("監控資料夾已恢復存取，繼續比對")
                    self.events.put(("state", "online"))
                old_keys, new_keys = set(self.previous), set(current)
                for path in sorted(new_keys - old_keys):
                    self._change("新增", path, None, current[path][1])
                for path in sorted(old_keys & new_keys):
                    missing.pop(path, None)
                    old_data, new_data = self.previous[path][1], current[path][1]
                    if old_data != new_data:
                        self._change("修改/取代", path, old_data, new_data)
                for path in sorted(old_keys - new_keys):
                    missing[path] = missing.get(path, 0) + 1
                    if missing[path] >= DELETE_CONFIRM_CYCLES:
                        missing.pop(path)
                        self._change("刪除", path, self.previous[path][1], None)
                    else:
                        current[path] = self.previous[path]   # 先保留，下一輪仍找不到才算刪除
                self.previous = current
                self.last_sync = time.time()
            if time.time() - last_disk >= DISK_REFRESH_SEC:
                last_disk = time.time()
                try:
                    u = shutil.disk_usage(str(self.backup))
                    self.disk = (u.total, u.used, u.free)
                except OSError:
                    pass
            self.wake_event.wait(interval)
            self.wake_event.clear()
        self.events.put(("status", "已停止"))

    def _change(self, action, path, old, new):
        src = Path(path)
        rel = self._relative(src)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        # Before/after content is sourced from the cached snapshots, not reread later.
        if old is not None:
            self._save_bytes(old, rel, f"BEFORE_{stamp}")
        if new is not None:
            self._save_bytes(new, rel, f"AFTER_{stamp}")
        diff_name = ""
        if old is not None and new is not None:
            diff_name = self._save_diff(old, new, rel, stamp)
        if old is not None and new is not None:
            detail = summarize_changes(old, new)
            if detail is None:   # 非參數格式或只有空白／換行差異 → 退回雜湊與大小
                detail = f"內容已變更（無參數差異） before={sha256_bytes(old)[:12]}({len(old)}B) after={sha256_bytes(new)[:12]}({len(new)}B)"
        elif new is not None:
            detail = f"新檔案（{len(new)}B）"
        else:
            detail = f"檔案已刪除（原 {len(old)}B）" if old is not None else "檔案已刪除"
        msg = f"{action} | file={path} | {detail}"
        self._log(msg)
        self.events.put(("event", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), action, src.name, detail, path, old, new)))
        if self.notify_var.get():
            self.events.put(("notify", f"{action}: {src.name}"))

    def _relative(self, path):
        try: return Path(os.path.relpath(str(path), self.folder))
        except ValueError: return Path(path.name)

    def _save_bytes(self, data, rel, prefix):
        dest_dir = self.backup / "versions" / rel.parent
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / f"{rel.stem}_{prefix}{rel.suffix}"
        dest.write_bytes(data)
        return dest

    def _save_diff(self, old, new, rel, stamp):
        old_lines = decode_text(old).splitlines(keepends=True)
        new_lines = decode_text(new).splitlines(keepends=True)
        diff = difflib.unified_diff(old_lines, new_lines,
            fromfile=f"before/{rel}", tofile=f"after/{rel}")
        text = "".join(diff)
        dest_dir = self.backup / "diff" / rel.parent
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / f"{rel.stem}_{stamp}.diff.txt"
        dest.write_text(text or "(無文字差異；可能是二進位或換行格式變更)\n", encoding="utf-8")
        return str(dest)

    def _log(self, message):
        line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}] {message}\n"
        try:
            with self.log_path.open("a", encoding="utf-8") as f: f.write(line)
        except Exception: pass

    def _set_cfg_enabled(self, enabled):
        for w in self._cfg_widgets:
            try: w.configure(state="normal" if enabled else "disabled")
            except tk.TclError: pass
        self.cfg_note_var.set("資料夾與輪詢間隔會在按下「開始監控」時套用。" if enabled
                              else "監控中：資料夾與輪詢間隔已鎖定，停止監控後才能修改。")

    def _poll_ui(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "event":
                    t, action, name, detail, path, old, new = payload
                    self._record_event(action, name, detail, path, old, new, t)
                elif kind == "notify":
                    self.status_var.set("有變更：" + payload)
                    self.root.after(2200, lambda: self.status_var.set(self._idle_status())
                                    if self.status_var.get().startswith("有變更") else None)
                elif kind == "status":
                    self.status_var.set("待機中")
                    self.start_btn.configure(state="normal")
                    self.stop_btn.configure(state="disabled")
                    self._set_cfg_enabled(True)
                elif kind == "state":
                    self.status_var.set(self._idle_status())
        except queue.Empty:
            pass
        self.root.after(120, self._poll_ui)

    def show_diff(self, event=None):
        tree = event.widget if event is not None and isinstance(event.widget, ttk.Treeview) else self.ev_tree
        selected = tree.selection()
        if not selected: return
        data = self._diff_cache.get(selected[0])
        if not data: return
        path, old, new = data
        if old is None or new is None:
            messagebox.showinfo("差異", "新增、刪除或開始事件沒有前後兩份內容可比較。"); return
        win = tk.Toplevel(self.root)
        win.title(f"PAR 差異 - {Path(path).name}")
        win.geometry("940x600")
        win.configure(bg=BG)
        head = tk.Label(win, text=f"◆ DIFF  {Path(path).name}", bg=BG, fg=CYAN, font=("Consolas", 12, "bold"), anchor="w")
        head.pack(fill="x", padx=14, pady=(12, 6))
        frame = tk.Frame(win, bg=BORDER, padx=1, pady=1)
        frame.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        text = tk.Text(frame, wrap="none", bg=PANEL, fg=FG, insertbackground=CYAN, font=FONT_MONO,
                       relief="flat", borderwidth=0, padx=10, pady=8, selectbackground="#17406b")
        ys = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        xs = ttk.Scrollbar(frame, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y"); xs.pack(side="bottom", fill="x")
        text.pack(fill="both", expand=True)
        text.tag_configure("add", foreground=GREEN, background="#0c2a22")
        text.tag_configure("rem", foreground=RED, background="#2e1220")
        text.tag_configure("hunk", foreground=CYAN)
        text.tag_configure("hdr", foreground=AMBER)
        lines = list(difflib.unified_diff(decode_text(old).splitlines(), decode_text(new).splitlines(),
            fromfile="修改前", tofile="修改後", lineterm=""))
        if not lines:
            text.insert("1.0", "無文字差異")
        for ln in lines:
            if ln.startswith(("+++", "---")): tag = "hdr"
            elif ln.startswith("@@"): tag = "hunk"
            elif ln.startswith("+"): tag = "add"
            elif ln.startswith("-"): tag = "rem"
            else: tag = ""
            text.insert("end", ln + "\n", tag)
        text.configure(state="disabled")

    def stop(self):
        self.stop_event.set()
        self.wake_event.set()
        if self.observer:
            try: self.observer.stop(); self.observer.join(timeout=2)
            except Exception: pass
            self.observer = None
        self.status_var.set("停止中…")
        self.stop_btn.configure(state="disabled")

    def open_backup(self):
        if self.backup and self.backup.exists(): self._open_path(self.backup)
        else: messagebox.showinfo("提示", "請先開始監控。")

    def open_log(self):
        if self.log_path and self.log_path.exists(): self._open_path(self.log_path)
        else: messagebox.showinfo("提示", "尚未產生 Log。")

    @staticmethod
    def _open_path(path):
        try:
            if os.name == "nt": os.startfile(str(path))
            elif sys.platform == "darwin": subprocess.Popen(["open", str(path)])
            else: subprocess.Popen(["xdg-open", str(path)])
        except Exception as e: messagebox.showerror("開啟失敗", str(e))

    def install_autostart(self):
        if os.name != "nt": raise RuntimeError("此功能只支援 Windows")
        startup = Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs/Startup"
        startup.mkdir(parents=True, exist_ok=True)
        target = startup / "PAR檔案監控器.bat"
        exe = Path(sys.executable)
        if getattr(sys, "frozen", False):
            command = f'"{exe}"'
        else:
            command = f'"{exe}" "{Path(__file__).resolve()}"'
        target.write_text("@echo off\r\nstart \"\" " + command + "\r\n", encoding="utf-8")
        return target

    def close(self):
        self.stop_event.set()
        self.wake_event.set()
        if self.observer:
            try: self.observer.stop(); self.observer.join(timeout=1)
            except Exception: pass
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ParMonitor(root)
    root.mainloop()

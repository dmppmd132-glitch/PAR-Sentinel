@echo off
chcp 65001 >nul
py -3.12 -m pip install pyinstaller watchdog
py -3.12 -m PyInstaller --noconsole --onefile --clean --name PAR_Monitor --icon "backup-records-icon.ico" --add-data "backup-records-icon.ico;." PAR.py
echo.
echo 完成：dist\PAR_Monitor.exe
pause
